package priv.tzk.course.servlet;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import priv.tzk.course.entity.Course;
import priv.tzk.course.service.courseService;

/**
 * Servlet implementation class courseServlet
 */
@WebServlet("/courseServlet")
public class courseServlet extends HttpServlet{
    private static final long serialVersionUID = 1L;

    courseService service=new courseService();

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        /**
         * ����ѡ��
         */
        req.setCharacterEncoding("utf-8");
        String method = req.getParameter("method");
        if ("add".equals(method)) {
            add(req, resp);
        } else if ("delete".equals(method)) {
            delete(req, resp);
        } else if ("update".equals(method)) {
            update(req, resp);
        } else if ("select".equals(method)) {
            select(req, resp);
        } else if ("getCoursebyName".equals(method)) {
        	getCoursebyName(req, resp);
        } else if ("getCoursebyName2".equals(method)) {
        	getCoursebyName2(req, resp);
        }   else if ("list".equals(method)) {
            list(req, resp);
        }
    }


    private void add(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
    	//����
        req.setCharacterEncoding("utf-8");
        String name = req.getParameter("name");
        String teacher = req.getParameter("teacher");
        String classroom = req.getParameter("classroom");
        Course course= new Course(name, teacher, classroom);
        
        //�ж��Ƿ�����
        if(service.add(course)) {
            req.setAttribute("message", "���ӳɹ�");//setAttribute�������ڽ����ݱ����ڶ����У�������һ��ҳ����
            req.getRequestDispatcher("add.jsp").forward(req,resp);//getRequestDispatcher�������ڽ�����һ��ҳ��
        } else {
            req.setAttribute("message", "�γ������ظ���������¼��");
            req.getRequestDispatcher("add.jsp").forward(req,resp);
        }
    }
    

    private void delete(HttpServletRequest req, HttpServletResponse resp)throws IOException, ServletException{
    	// ɾ��
        req.setCharacterEncoding("utf-8");
        String name = req.getParameter("name");
        service.delete(name);
        req.setAttribute("message", "�γ���Ϣɾ���ɹ�");
        req.getRequestDispatcher("deletebyName.jsp").forward(req,resp);
    }


    private void getCoursebyName2(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
    	/*
    	 * ͨ�����ֵõ�
    	 * ��ת���޸�
    	 */
        req.setCharacterEncoding("utf-8");
        String name = req.getParameter("name");
        Course course =service.getCoursebyName(name);       
        req.setAttribute("course", course);
        req.getRequestDispatcher("update.jsp").forward(req,resp);
        
    }
    

    private void getCoursebyName(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
    	/*
    	 * ͨ�����ֲ���
    	 * ��ת��ɾ��
    	 */
        req.setCharacterEncoding("utf-8");
        String name = req.getParameter("name");
        Course course =service.getCoursebyName(name);
        if(course == null) {
            req.setAttribute("message", "���޴˿γ̣�");
            req.getRequestDispatcher("deletebyName.jsp").forward(req,resp);
        } else {
            req.setAttribute("course", course);
            req.getRequestDispatcher("delete.jsp").forward(req,resp);
        }
    }
    

    private void list(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
    	//�г�ȫ����Ϣ
        req.setCharacterEncoding("utf-8");
        List<Course> course = service.list();
        req.setAttribute("courses",course);
        req.getRequestDispatcher("list.jsp").forward(req,resp);
    }

    private void update(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
    	//�޸�
        req.setCharacterEncoding("utf-8");
        String name = req.getParameter("name");
        String teacher = req.getParameter("teacher");
        String classroom = req.getParameter("classroom");
        Course course = new Course(name,teacher, classroom);        
        int k=service.update(course);
        if(k==0) {
        	req.setAttribute("message", "�޸�ʧ��");
			req.getRequestDispatcher("courseServlet?method=list").forward(req,resp);
        }else if(k==1){
        req.setAttribute("message", "�޸ĳɹ�");
        req.getRequestDispatcher("courseServlet?method=list").forward(req,resp);
        }
    }

    private void select(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
    	//����
        req.setCharacterEncoding("utf-8");
        String name = req.getParameter("name");
        String teacher = req.getParameter("teacher");
        String classroom = req.getParameter("classroom");
        List<Course> course = service.select(name, teacher, classroom);
        req.setAttribute("courses", course);
        req.getRequestDispatcher("selectlist.jsp").forward(req,resp);
 
    }
}