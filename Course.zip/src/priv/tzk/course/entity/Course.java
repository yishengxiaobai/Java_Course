package priv.tzk.course.entity;

public class Course {

	private int id;
    private String name;
    private String teacher;
    private String classroom;
    public void setId(int id) {
    	this.id=id;
	}
	public int getId() {
    	return id;
	}
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getTeacher() {
        return teacher;
    }
    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }
    public String getClassroom() {
        return classroom;
    }
    public void setClassroom(String classroom) {
        this.classroom = classroom;
    }
    
    public Course() {}

    public Course(String name, String teacher, String classroom) {
        this.name = name;
        this.teacher = teacher;
        this.classroom = classroom;
    }
}
