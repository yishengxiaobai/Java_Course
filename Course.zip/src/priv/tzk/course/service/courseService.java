package priv.tzk.course.service;

import java.util.List;

import priv.tzk.course.dao.Dao;
import priv.tzk.course.entity.Course;

public class courseService{
    Dao dao=new Dao();
    public  boolean add(Course course) {
        boolean bean=false;
        if(!dao.rename(course.getName())) {
        	//����Ƿ���������Ļ�ִ����һ��
        	dao.add(course);
        	bean=true;
        }
        return bean;
    }
    public void delete(String name) {
    	dao.delete(name);
    }
    public int update(Course course) {
    	int f=0;
		if(dao.update(course)) {
			f=1;
		}
		return f;
    }
   
    public Course getCoursebyName(String name) {
    	//ͨ��Name�õ�һ��Course
        return dao.getCoursebyName(name);
    }
    
    public List<Course> select(String name, String teacher, String classroom) {
    	//����
        return dao.select(name, teacher, classroom);
    }

    public List<Course> list() {
    	//�г�����������Ϣ
        return dao.list();
    }
}
