package priv.tzk.course.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import priv.tzk.course.dbUtil.Shujuku;
import priv.tzk.course.entity.Course;

public class Dao {
	
	/*
	 * ����������ΪBoolean���ͣ�ֻ������ֵ���ֵ��service�㣬����
	 */
	
	public boolean rename(String name) {
		//�������ݿ��course������Ƿ�����
		String sql = "select * from courses where name ='" + name + "'";
        Connection conn =Shujuku.conn() ;
        Statement st= null;
        ResultSet rs = null;
        boolean bean=false;
        try {
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()) {
            	bean = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Shujuku.close(rs,st, conn);
        }
        return bean;
	}

	public boolean add(Course course) {
		//����
		 	String sql = "insert into courses(name, teacher, classroom) values('" + course.getName() + "','" + course.getTeacher() + "','" + course.getClassroom() + "')";
	     	Connection conn =Shujuku.conn() ;
	    	Statement st= null;
	     	boolean bean = false;
	        int a = 0;
	        
	        try {
	            st = conn.createStatement();
	            st.executeUpdate(sql);
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            Shujuku.close(st, conn);
	        }
	        
	        if (a > 0) {
	            bean = true;
	        }
	        return bean;
		
	}

	public boolean delete(String name) {
		// ͨ������ɾ��
		boolean f=false;
		String sql = "delete from courses where name ='" + name + "'";//ɾ��
		Connection conn = Shujuku.conn();
		Statement state = null;
		int a=0;
		try {
			state = conn.createStatement();
			a=state.executeUpdate(sql);
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			Shujuku.close(state, conn);
		}
		if(a>0) {
			f=true;
		}
		return f;
	}

	public boolean update(Course course) {
		// �޸�
		String sql = "update courses set teacher='" + course.getTeacher() + "', classroom='" + course.getClassroom()+"'where name='"+course.getName()+"'";
		Connection conn = Shujuku.conn();
		Statement state = null;
		boolean f = false;
		int a = 0;

		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Shujuku.close(state, conn);
		}
	
		if (a > 0) {
			f = true;
		}
		return f;
		
	}

	public Course getCoursebyName(String name) {
		 String sql = "select * from courses where name ='" + name + "'";
	        Connection conn =Shujuku.conn() ;
	        Statement st= null;
	        ResultSet rs = null;
	        Course course=null;
	        try {
	            st = conn.createStatement();
	            rs = st.executeQuery(sql);
	            while (rs.next()) {
	                String teacher = rs.getString("teacher");
	                String classroom = rs.getString("classroom");
	                course = new Course(name, teacher, classroom);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            Shujuku.close(rs,st, conn);
	        }
	        return course;
	}

	public List<Course> select(String name, String teacher, String classroom) {
		String sql = "select * from courses where ";
			if (name !=null) {
				sql += "name like '%" + name + "% '";
			}else if(name==null) {
				sql += " ";
			}
			if (name !=null&&teacher !=null) {
	            sql += "and teacher like '%" + teacher + "% '";
	        }else if(name==null&&teacher !=null) {
				sql += "teacher like '%" + teacher + "% '";
			}else if(teacher==null) {
				sql += " ";
			}
			if ((name!=null||teacher !=null)&&classroom !=null) {
	            sql += "and classroom like '%" + classroom + "%'";
	        }else if(name==null&&teacher==null&&classroom !=null) {
				sql += "teacher like '%" + teacher + "% '";
			}else if(classroom==null) {
				sql += " ";
			}
	        List<Course> list = new ArrayList<>();
	        Connection conn =Shujuku.conn() ;
	        Statement st= null;
	        ResultSet rs = null;
	        try {
	            st = conn.createStatement();
	            rs = st.executeQuery(sql);
	            Course course=null;
	            while (rs.next()) {
	                String name2 = rs.getString("name");
	                String teacher2 = rs.getString("teacher");
	                String classroom2 = rs.getString("classroom");
	                course= new Course(name2, teacher2, classroom2);
	                list.add(course);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            Shujuku.close(rs,st, conn);
	        }
	        return list;

	}

	public List<Course> list() {
		String sql = "select * from courses";
		List<Course> list = new ArrayList<>();
        Connection conn =Shujuku.conn() ;
        Statement st= null;
        ResultSet rs = null;
        try {
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            Course course=null;
            while (rs.next()) {
                String name2 = rs.getString("name");
                String teacher2 = rs.getString("teacher");
                String classroom2 = rs.getString("classroom");
                course= new Course(name2, teacher2, classroom2);
                list.add(course);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Shujuku.close(rs,st, conn);
        }
        return list;

	}

}
